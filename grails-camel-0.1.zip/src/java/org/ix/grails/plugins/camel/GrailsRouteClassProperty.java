package org.ix.grails.plugins.camel;

/**
 * Created by IntelliJ IDEA.
 * User: navtach
 * Date: Mar 16, 2009
 * Time: 3:56:43 PM
 * To change this template use File | Settings | File Templates.
 */
public interface GrailsRouteClassProperty {

	public static final String CONFIGURE = "configure";
	public static final String ROUTE = "Route";

}
