/**
 * Created by IntelliJ IDEA.
 * User: navtach
 * Date: Mar 17, 2009
 * Time: 4:25:38 PM
 * To change this template use File | Settings | File Templates.
 */

public class TestController {

	def test = {
		return "fdassfaffdasfdsfdasfsdafd"
	}

}