import org.ix.grails.plugins.camel.GrailsRouteBuilder

/**
 * Created by IntelliJ IDEA.
 * User: navtach
 * Date: Mar 12, 2009
 * Time: 1:28:52 PM
 * To change this template use File | Settings | File Templates.
 */

public class DefaultRoutes extends GrailsRouteBuilder {

	public void configure()
	{
		from('seda:grails.plugin.camel.test').to('stream:out')
	}

}